package com.avega.jpa.controller;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.avega.jpa.entity.Employee;
import com.avega.jpa.properties.LocalDateProperty;
import com.avega.jpa.service.EmployeeService;
import com.avega.jpa.service.RoleService;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;

	@InitBinder
	public void employebiner(WebDataBinder webDataBinder) {
		// DateFormatter dateFormatter = new DateFormatter("yyyy-MM-dd");
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//		webDataBinder.registerCustomEditor(LocalDate.class, "doj", new CustomDateEditor(formatter,true));
		webDataBinder.registerCustomEditor(LocalDate.class, "doj", new LocalDateProperty());

	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String getAllEmployees() {
		return "home";
	}

	@RequestMapping(value = "/details", method = RequestMethod.GET)
	public String getAllEmployees(Model model) {
		model.addAttribute("listOfEmployees", employeeService.findAllEmployees());
		return "details";
	}

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public String addEmployee(Model model) {
		model.addAttribute(new Employee());
		return "create";
	}

	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateEmployee(@RequestParam String empId, Model model) {
		Optional<Employee> emplOptional = employeeService.findByEmployeeId(empId);
		if (emplOptional.isPresent())
			model.addAttribute(emplOptional.get());
		return "update";
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveEmployee(@ModelAttribute("employee") Employee employee) {
		employeeService.addEmployee(employee);
		return "redirect:/details";
	}

	@RequestMapping(value = "/update-save", method = RequestMethod.POST)
	public String saveUpdateEmployee(@ModelAttribute("employee") Employee employee) {
		employeeService.updateEmployee(employee);
		return "redirect:/details";
	}

	@RequestMapping(value = "/delete/{empId}")
	public String deleteEmployee(@PathVariable String empId) {
		Optional<Employee> employee = employeeService.findByEmployeeId(empId);
		if (employee.isPresent())
			employeeService.deleteEmployee(employee.get());
		return "redirect:/details";
	}

}
