package com.avega.jpa.properties;

import java.beans.PropertyEditorSupport;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class LocalDateProperty extends PropertyEditorSupport {
	
	@Override
	public void setAsText(String text) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate localDate = LocalDate.parse(text, formatter);
		setValue(localDate);
	}
}
